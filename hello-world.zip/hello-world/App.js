import React, { Component } from "react";
import {
  Text,
  View,
  FlatList,
  Alert,
  StatusBar,
  ActivityIndicator,
  Image,
  TouchableOpacity,
  Button,
  ToastAndroid,
  Animated,
  StyleSheet,
} from "react-native";
import { scale, verticalScale } from "react-native-size-matters";
import NetInfo from "@react-native-community/netinfo";
export default class main extends Component {
  constructor(props) {
    super(props);
    this.state = {
      data: [],
      loader: true,
      visible: false,
      refreshing: true,
      net: null,
      btn_press: false,
      fadeAnim: new Animated.Value(0),
    };
  }
  componentDidMount() {
    this.netinfo();
  }

  netinfo() {
    NetInfo.fetch().then((state) => {
      if (state.isConnected == true) {
        this.setState({ net: "on" });
        this.getdata();
        // console.log("connected");
      } else {
        // console.log("not connected");
      }
    });
  }
  handleRefresh = () => {
    this.setState({ refreshing: false }, () => {
      this.getdata();
    });
  };
  getdata() {
    fetch(
      "https://gist.githubusercontent.com/t-reed/739df99e9d96700f17604a3971e701fa/raw/1d4dd9c5a0ec758ff5ae92b7b13fe4d57d34e1dc/waracle_cake-android-client"
    )
      .then((response) => response.json())
      .then((json) => {
        var setObj = new Set();
        this.setState({
          data: json.reduce((acc, item) => {
            if (!setObj.has(item.title)) {
              setObj.add(item.title, item);
              acc.push(item);
            }
            return acc;
          }, []),
        });

        this.state.data.sort(function (a, b) {
          var nameA = a.title.toUpperCase();
          var nameB = b.title.toUpperCase();
          if (nameA < nameB) {
            return -1;
          }
          if (nameA > nameB) {
            return 1;
          }
          return 0;
        });
        this.setState({ refreshing: false });
        this.setState({ loader: false });

        this.animation();
        // console.log( this.state.data.length);
      })
      .catch((error) => {
        console.error(error);
      });
  }
  animation() {
    Animated.timing(this.state.fadeAnim, {
      toValue: 1,
      duration: 5000,
    }).start();
  }

  render() {
    return this.state.net == "on" ? (
      <View style={styles.flex}>
        {/* header */}
        <View style={styles.header_View}>
          <Text style={styles.header_text}>cake details</Text>
        </View>
        <Animated.View
          style={{
            flexDirection: "column",
            opacity: this.state.fadeAnim,
          }}
        >
          {this.state.loader && (
            <ActivityIndicator
              size="small"
              style={{ margin: 10 }}
              color="#fe672d"
            />
          )}
          <FlatList
            data={this.state.data}
            refreshing={this.state.refreshing}
            onRefresh={this.handleRefresh}
            renderItem={({ item }) => (
              <TouchableOpacity
                onPress={() => {
                  Alert.alert(item.title, "Description: " + item.desc);
                }}
                style={styles.Flat_view}
              >
                <Image style={styles.cakeImage} source={{ uri: item.image }} />
                <Text style={{ margin: verticalScale(5) }}>{item.title}</Text>
              </TouchableOpacity>
            )}
          />
        </Animated.View>
      </View>
    ) : (
      <View style={styles.netinfo_view}>
        <Text style={styles.netinfo_text}>No network Connection</Text>
        <TouchableOpacity
          style={styles.netinfo_btn}
          onpress={() => {
            this.forceUpdate();
            this.state.net == "on"
              ? this.netinfo()
              : ToastAndroid.show("not connected", ToastAndroid.SHORT);
          }}
        >
          <Text style={styles.netinfo_text2}>Try Again</Text>
        </TouchableOpacity>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  flex: {
    flex: 1,
  },
  header_View: {
    backgroundColor: "#fe672d",
    justifyContent: "center",
    alignItems: "center",
    height: verticalScale(70),
  },
  header_text: {
    fontSize: verticalScale(20),
    color: "#ffffff",
  },
  Flat_view: {
    flex: 1,
    alignItems: "center",
    flexDirection: "row",
    margin: 8,
    borderRadius: 5,
    backgroundColor: "#f5f5f5",
  },
  cakeImage: {
    width: verticalScale(50),
    height: verticalScale(50),
    margin: verticalScale(15),
  },
  netinfo_view: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
  },
  netinfo_text: {
    fontSize: 18,
    color: "#000000",
    margin: 10,
  },
  netinfo_btn: {
    backgroundColor: "#fe672d",
    justifyContent: "center",
    alignItems: "center",
  },
  netinfo_text2: {
    fontSize: 20,
    color: "#ffffff",
    margin: 15,
  },
});
